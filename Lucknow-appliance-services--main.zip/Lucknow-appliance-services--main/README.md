<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Appliance Repair Service</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to Our Home Appliance Repair Service</h1>
        <nav>
            <ul>
                <li><a href="#about">About Us</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#contact">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    <section id="about">
        <h2>About Us</h2>
        <p>We are a professional home appliance repair service dedicated to providing the best repair solutions for your appliances.</p>
    </section>
    <section id="services">
        <h2>Our Services</h2>
        <ul>
            <li>Refrigerator Repair</li>
            <li>Washing Machine Repair</li>
            <li>Oven Repair</li>
            <li>Dishwasher Repair</li>
            <li>Microwave Repair</li>
        </ul>
    </section>
    <section id="contact">
        <h2>Contact Us</h2>
        <p>For inquiries, please reach out at: <a href="mailto:info@applianceservice.com">info@applianceservice.com</a></p>
    </section>
    <footer>
        <p>&copy; 2026 Home Appliance Repair Service. All Rights Reserved.</p>
    </footer>
</body>
</html>
